import DashboardLayout from '../../components/layout/DashboardLayout'
import StatCard from '../../components/cards/StatCard'
import Card from '../../components/common/Card'
import {
  getCurrentStudent,
  topicLogsData,
  assignmentsData,
  marksRecordsData,
} from '../../data/dummyData'

export default function StudentDashboard() {
  const student = getCurrentStudent()
  const myBatch = student?.batch

  const myAssignments = assignmentsData.filter((a) => a.batch === myBatch)
  const openAssignments = myAssignments.filter((a) => a.status === 'Open')

  const myAssessments = marksRecordsData.filter((m) => m.batch === myBatch)
  const myAvgPercent = myAssessments.length
    ? Math.round(
        myAssessments.reduce((sum, m) => {
          const mine = m.scores.find((s) => s.name === student.name)
          return sum + (mine ? (mine.score / m.totalMarks) * 100 : 0)
        }, 0) / myAssessments.length
      )
    : 0

  const latestTopic = topicLogsData
    .filter((t) => t.batch === myBatch)
    .slice()
    .sort((a, b) => (a.date < b.date ? 1 : -1))[0]

  const stats = [
    { label: 'Attendance', value: student?.attendance ?? 0, suffix: '%', icon: 'bi-check2-square' },
    { label: 'Open Assignments', value: openAssignments.length, icon: 'bi-clipboard-check' },
    { label: 'Avg. Marks', value: myAvgPercent, suffix: '%', icon: 'bi-graph-up' },
    { label: 'Batch', value: myBatch || '—', icon: 'bi-collection' },
  ]

  return (
    <DashboardLayout title="Student Dashboard">
      <div className="row g-3 mb-3">
        {stats.map((s) => (
          <div className="col-12 col-sm-6 col-lg-3" key={s.label}>
            <StatCard {...s} />
          </div>
        ))}
      </div>

      <div className="row g-3">
        <div className="col-12 col-lg-6">
          <Card title="Today's topic" eyebrow={myBatch}>
            <div className="pulse-line" />
            {latestTopic ? (
              <>
                <div style={{ fontWeight: 600 }}>{latestTopic.topic}</div>
                <div className="st-eyebrow mt-1">{latestTopic.date}</div>
                {latestTopic.homework && (
                  <div className="mt-2" style={{ fontSize: '0.85rem' }}>
                    <strong>Homework:</strong> {latestTopic.homework}
                  </div>
                )}
              </>
            ) : (
              <p className="text-muted mb-0">No topics logged yet for your batch.</p>
            )}
          </Card>
        </div>

        <div className="col-12 col-lg-6">
          <Card title="Assignments due" eyebrow="Upcoming">
            <div className="pulse-line" />
            {openAssignments.length === 0 && <p className="text-muted mb-0">Nothing due right now. Nice!</p>}
            <div className="d-flex flex-column gap-2">
              {openAssignments.map((a) => (
                <div
                  key={a.id}
                  className="d-flex align-items-center justify-content-between flex-wrap gap-2 p-2"
                  style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)' }}
                >
                  <span style={{ fontWeight: 600 }}>{a.title}</span>
                  <span className="st-badge st-badge-warning">Due {a.dueDate}</span>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
