import { useState } from 'react'
import DashboardLayout from '../../components/layout/DashboardLayout'
import Card from '../../components/common/Card'
import PdfUpload from '../../components/common/PdfUpload'
import { getCurrentStudent, assignmentsData } from '../../data/dummyData'

// Demo seed: pretend the current student already submitted the closed assignment.
const SEED_SUBMISSIONS = {
  2: { fileName: 'streams-practice-aditi.pdf', fileUrl: '', submittedAt: '2026-07-05' },
}

export default function Assignments() {
  const student = getCurrentStudent()
  const myAssignments = assignmentsData.filter((a) => a.batch === student?.batch)
  const [submissions, setSubmissions] = useState(SEED_SUBMISSIONS)

  const handleSubmit = (assignmentId, file) => {
    if (!file) return
    setSubmissions((prev) => ({
      ...prev,
      [assignmentId]: { ...file, submittedAt: new Date().toISOString().slice(0, 10) },
    }))
  }

  const handleWithdraw = (assignmentId) => {
    setSubmissions((prev) => {
      const next = { ...prev }
      delete next[assignmentId]
      return next
    })
  }

  return (
    <DashboardLayout title="Assignments">
      <div className="d-flex flex-column gap-3">
        {myAssignments.length === 0 && (
          <Card>
            <p className="text-muted mb-0">No assignments for your batch yet.</p>
          </Card>
        )}

        {myAssignments.map((a) => {
          const mySubmission = submissions[a.id]
          return (
            <Card key={a.id} title={a.title} eyebrow={a.batch}>
              <div className="pulse-line" />

              <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-2">
                <span className={`st-badge ${a.status === 'Open' ? 'st-badge-success' : 'st-badge-red'}`}>
                  {a.status}
                </span>
                <span className="st-eyebrow">Due {a.dueDate}</span>
              </div>

              {a.description && <p style={{ fontSize: '0.88rem' }}>{a.description}</p>}

              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <div className="st-eyebrow mb-1">Assignment material</div>
                  {a.fileUrl ? (
                    <a href={a.fileUrl} target="_blank" rel="noreferrer" download={a.fileName} className="btn btn-st-outline btn-sm">
                      <i className="bi bi-file-earmark-pdf me-1" style={{ color: 'var(--red)' }} />
                      View PDF from trainer
                    </a>
                  ) : (
                    <p className="text-muted" style={{ fontSize: '0.85rem' }}>
                      No material attached for this assignment.
                    </p>
                  )}
                </div>

                <div className="col-12 col-md-6">
                  <div className="st-eyebrow mb-1">Your submission</div>
                  {mySubmission ? (
                    <div
                      className="d-flex align-items-center justify-content-between p-2"
                      style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)' }}
                    >
                      <div className="text-truncate" style={{ fontSize: '0.85rem' }}>
                        <i className="bi bi-file-earmark-check me-1" style={{ color: 'var(--success)' }} />
                        {mySubmission.fileName}
                        <div className="st-eyebrow mt-1">Submitted {mySubmission.submittedAt}</div>
                      </div>
                      <button className="btn btn-sm btn-st-outline flex-shrink-0" onClick={() => handleWithdraw(a.id)}>
                        Withdraw
                      </button>
                    </div>
                  ) : (
                    <PdfUpload label="Upload your submission" value={null} onChange={(file) => handleSubmit(a.id, file)} />
                  )}
                </div>
              </div>
            </Card>
          )
        })}
      </div>
    </DashboardLayout>
  )
}
