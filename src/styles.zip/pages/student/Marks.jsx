import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import DashboardLayout from '../../components/layout/DashboardLayout'
import Card from '../../components/common/Card'
import { getCurrentStudent, marksRecordsData } from '../../data/dummyData'

export default function Marks() {
  const student = getCurrentStudent()
  const myAssessments = marksRecordsData
    .filter((m) => m.batch === student?.batch)
    .map((m) => {
      const mine = m.scores.find((s) => s.name === student.name)
      const score = mine?.score ?? 0
      return {
        id: m.id,
        title: m.title,
        date: m.date,
        totalMarks: m.totalMarks,
        score,
        percent: Math.round((score / m.totalMarks) * 100),
      }
    })
    .sort((a, b) => (a.date < b.date ? 1 : -1))

  const chartData = myAssessments
    .slice()
    .sort((a, b) => (a.date > b.date ? 1 : -1))
    .map((m) => ({ name: m.title.length > 14 ? m.title.slice(0, 14) + '…' : m.title, percent: m.percent }))

  const average = myAssessments.length
    ? Math.round(myAssessments.reduce((sum, m) => sum + m.percent, 0) / myAssessments.length)
    : 0

  return (
    <DashboardLayout title="Marks">
      <div className="row g-3">
        <div className="col-12 col-lg-5">
          <Card title="Average score" eyebrow={student?.batch}>
            <div className="pulse-line" />
            <div className="stat-number" style={{ fontSize: '2rem' }}>
              {average}%
            </div>
            <div className="pulse-progress mt-1">
              <span style={{ width: `${average}%` }} />
            </div>
            <div className="st-eyebrow mt-2">Across {myAssessments.length} assessments</div>
          </Card>
        </div>

        <div className="col-12 col-lg-7">
          <Card title="Score trend" eyebrow="By assessment">
            <div className="pulse-line" />
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={chartData}>
                <CartesianGrid stroke="var(--border)" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} stroke="var(--ink-muted)" />
                <YAxis tick={{ fontSize: 12 }} stroke="var(--ink-muted)" domain={[0, 100]} />
                <Tooltip />
                <Bar dataKey="percent" fill="var(--red)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </div>

        <div className="col-12">
          <Card title="All assessments" eyebrow="Detail">
            <div className="pulse-line" />
            <div className="table-responsive">
              <table className="table table-borderless align-middle mb-0">
                <thead>
                  <tr className="st-eyebrow">
                    <th>Assessment</th>
                    <th>Date</th>
                    <th>Score</th>
                  </tr>
                </thead>
                <tbody>
                  {myAssessments.map((m) => (
                    <tr key={m.id}>
                      <td style={{ fontWeight: 600 }}>{m.title}</td>
                      <td className="text-muted">{m.date}</td>
                      <td style={{ minWidth: 140 }}>
                        <div className="pulse-progress">
                          <span style={{ width: `${m.percent}%` }} />
                        </div>
                        <div className="st-eyebrow mt-1">
                          {m.score} / {m.totalMarks} ({m.percent}%)
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
