import DashboardLayout from '../../components/layout/DashboardLayout'
import Card from '../../components/common/Card'
import { getCurrentStudent, topicLogsData } from '../../data/dummyData'

export default function Topics() {
  const student = getCurrentStudent()
  const myTopics = topicLogsData
    .filter((t) => t.batch === student?.batch)
    .slice()
    .sort((a, b) => (a.date < b.date ? 1 : -1))

  return (
    <DashboardLayout title="Topics">
      <Card title="Session history" eyebrow={student?.batch}>
        <div className="pulse-line" />
        {myTopics.length === 0 && <p className="text-muted mb-0">No topics logged yet for your batch.</p>}
        <div className="d-flex flex-column gap-3">
          {myTopics.map((t) => (
            <div key={t.id} className="p-2" style={{ borderLeft: '3px solid var(--red)', paddingLeft: '0.75rem' }}>
              <div className="d-flex align-items-center justify-content-between flex-wrap gap-2">
                <span className="st-badge st-badge-red">{t.course}</span>
                <span className="st-eyebrow">{t.date}</span>
              </div>
              <div style={{ fontWeight: 600, marginTop: 4 }}>{t.topic}</div>
              {t.duration && <div className="st-eyebrow mt-1">Duration: {t.duration} hrs</div>}
              {t.homework && (
                <div className="mt-1" style={{ fontSize: '0.85rem' }}>
                  <strong>Homework:</strong> {t.homework}
                </div>
              )}
              {t.remarks && (
                <div className="text-muted mt-1" style={{ fontSize: '0.85rem' }}>
                  {t.remarks}
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>
    </DashboardLayout>
  )
}
