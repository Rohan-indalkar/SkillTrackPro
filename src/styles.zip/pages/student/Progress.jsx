import DashboardLayout from '../../components/layout/DashboardLayout'
import Card from '../../components/common/Card'
import { getCurrentStudent, marksRecordsData } from '../../data/dummyData'

// Assignment completion isn't tracked in a shared store yet (submissions currently
// live only in local state on the Assignments page) — using a representative
// placeholder here until that's wired to a real backend in Day 6+.
const ASSIGNMENT_COMPLETION_PLACEHOLDER = 80

export default function Progress() {
  const student = getCurrentStudent()

  const myAssessments = marksRecordsData
    .filter((m) => m.batch === student?.batch)
    .map((m) => {
      const mine = m.scores.find((s) => s.name === student.name)
      const score = mine?.score ?? 0
      return { title: m.title, percent: Math.round((score / m.totalMarks) * 100) }
    })

  const marksAvg = myAssessments.length
    ? Math.round(myAssessments.reduce((sum, m) => sum + m.percent, 0) / myAssessments.length)
    : 0

  const weakest = myAssessments.length
    ? myAssessments.slice().sort((a, b) => a.percent - b.percent)[0]
    : null

  const metrics = [
    { label: 'Attendance', value: student?.attendance ?? 0, icon: 'bi-check2-square' },
    { label: 'Assignment Completion', value: ASSIGNMENT_COMPLETION_PLACEHOLDER, icon: 'bi-clipboard-check' },
    { label: 'Marks Average', value: marksAvg, icon: 'bi-graph-up' },
  ]

  const readinessScore = Math.round(metrics.reduce((sum, m) => sum + m.value, 0) / metrics.length)

  const readinessLabel = readinessScore >= 85 ? 'Ready for placement' : readinessScore >= 65 ? 'On track' : 'Needs focus'
  const readinessBadge = readinessScore >= 85 ? 'st-badge-success' : readinessScore >= 65 ? 'st-badge-warning' : 'st-badge-red'

  return (
    <DashboardLayout title="My Progress">
      <div className="row g-3">
        <div className="col-12 col-lg-4">
          <Card title="Placement readiness" eyebrow={student?.batch}>
            <div className="pulse-line" />
            <div className="stat-number" style={{ fontSize: '2.2rem' }}>
              {readinessScore}%
            </div>
            <span className={`st-badge ${readinessBadge} mt-2`}>{readinessLabel}</span>
            <div className="st-eyebrow mt-3">Based on attendance, assignments, and marks (equal weight)</div>
          </Card>
        </div>

        <div className="col-12 col-lg-8">
          <Card title="Breakdown" eyebrow="Contributing factors">
            <div className="pulse-line" />
            <div className="d-flex flex-column gap-3">
              {metrics.map((m) => (
                <div key={m.label}>
                  <div className="d-flex justify-content-between mb-1" style={{ fontSize: '0.85rem' }}>
                    <span>
                      <i className={`bi ${m.icon} me-1`} /> {m.label}
                    </span>
                    <span style={{ fontWeight: 600 }}>{m.value}%</span>
                  </div>
                  <div className="pulse-progress">
                    <span style={{ width: `${m.value}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <div className="col-12">
          <Card title="Focus area" eyebrow="Suggestion">
            <div className="pulse-line" />
            {weakest ? (
              <p className="mb-0">
                Your lowest-scoring assessment so far is <strong>{weakest.title}</strong> ({weakest.percent}%).
                Consider revisiting that topic and practicing a few extra problems before the next assessment.
              </p>
            ) : (
              <p className="text-muted mb-0">No assessments recorded yet — keep going!</p>
            )}
          </Card>
        </div>
      </div>
    </DashboardLayout>
  )
}
